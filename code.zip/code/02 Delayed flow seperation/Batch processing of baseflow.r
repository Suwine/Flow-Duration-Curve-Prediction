# Batch process all CSV files in a folder, splitting baseflow according to N:1-90.
rm(list = ls())

stringsAsFactors = FALSE

if (!require("hydrostats")) {
  install.packages("hydrostats")
}
if (!require("lfstat")) {
  install.packages("lfstat")
}
if (!require("segmented")) {
  install.packages("segmented")
}

library(hydrostats)
library(lfstat)
library(segmented)
baseflow_calculation <- function(input_folder, output_folder) {
 
  current_path <- normalizePath(dirname(rstudioapi::getActiveDocumentContext()$path))
  
  
  input_path <- file.path(current_path, input_folder)
  output_path <- file.path(current_path, output_folder)
  

  csv_files <- list.files(input_path, pattern = "*.csv")

  for (csv_file in csv_files) {

    data <- read.csv(file.path(input_path, csv_file))

    baseflow_list <- list()
    for (i in 1:90) {
      baseflow_i <- baseflow(data$Q, tp.factor = 0.9, block.len = i)
      baseflow_list[[i]] <- baseflow_i
    }
    baseflow_df <- data.frame(lapply(baseflow_list, function(x) x))
    colnames(baseflow_df) <- paste0("N", 1:length(baseflow_list))

    output_data <- cbind(data, baseflow_df)
    

    output_file <- file.path(output_path, paste0("baseflow_", csv_file))
    write.csv(output_data, file = output_file, row.names = FALSE)

    output_data <- output_data[complete.cases(output_data),]
    write.csv(output_data, file = output_file, row.names = FALSE)
  }
}
baseflow_calculation("continuous", "baseflow")