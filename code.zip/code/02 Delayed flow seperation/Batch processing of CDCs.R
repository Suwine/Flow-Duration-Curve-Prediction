#Plot the CDC curve.
rm(list = ls())
stringsAsFactors = FALSE

if (!require("segmented")) {
  install.packages("segmented")
}
library(segmented)
csv_file <- "C:\\Users\\Administrator\\dfi_result\\dfi_result.csv"
data_dfi <- read.csv(csv_file)
data_dfi <- data_dfi[ , -c(1:4)]
x <- 1:90
y <- as.numeric(data_dfi[9, ])
data <- data.frame(x = x, y = y)
new_point <- data.frame(x = 0, y = 1)
data <- rbind(data, new_point)
for (npsi in 1: 2 ){
  model <- segmented(lm(y ~ x, data=data), seg.Z = ~ x, npsi = npsi)
  adj_r_squared <- summary(model)$adj.r.squared
  psi <- summary(model)$psi
  print(adj_r_squared)
  print(psi)
}

new_psi <- (psi[1:(length(psi)-1)][3:4])
psi1 <- round(new_psi[1], digits = 0)
psi2 <- round(new_psi[2], digits = 0)
paste(psi1, psi2, sep = ", ")
point_colors <- ifelse(x <= psi1, "#F66F69",
                       ifelse(x <= psi2, "#FFBE7A", ifelse(x > 60, "#2878B5", "#8ECFC9")))
plot(x, y, main="CDC Curve(N07068000)", xlab="N", ylab="DFI", 
     col = point_colors,pch = 16, 
     xaxt = "n", yaxt = "n", ylim = c(0, 1), 
     cex = 1.5)
abline(v = c(0, 5, 15, 30, 60, 90), col = "gray", lty = "dotted")
abline(h = c(0, 0.25, 0.5, 0.75, 1), col = "gray", lty = "dotted")
#plot(model, add = TRUE, col = "black")

axis(side = 1, at = c(0, 5, 15, 30, 60, 90), 
     labels = c("0", "5", "15", "30", "60", "90"))
axis(side = 2, at = c(0, 0.25, 0.5, 0.75, 1), 
     labels = c("0", "0.25", "0.5", "0.75", "1"))
points(0, 1, col = "#F66F69", pch = 19, cex = 1.5)

plot(model, add = TRUE, col = "black")
