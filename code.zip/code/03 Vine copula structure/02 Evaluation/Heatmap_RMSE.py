'Plot a heatmap based on the RMSE values between the constructed FDC and the actual FDC.'
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
import numpy as np


data1 = pd.read_excel("C:/Users/Administrator/Desktop/Figures/4.results/Codes/1541000.xlsx", usecols=['百分位数','C更新前','V更新前'])

all_data = pd.concat([data1.iloc[:, 1:], data2.iloc[:, 1:], data3.iloc[:, 1:], data4.iloc[:, 1:], data5.iloc[:, 1:], data6.iloc[:, 1:], data7.iloc[:, 1:], data8.iloc[:, 1:], data9.iloc[:, 1:]])
global_min = all_data.min().min()
global_max = all_data.max().max()

sns.set_theme(style="white")

colors = ['#61AACF', '#98CADD', '#EAEFF6', '#E9EFEF', '#E9C6C6', '#DA9599']


cmap = matplotlib.colors.LinearSegmentedColormap.from_list("", colors)

def draw_and_save_heatmap(data, cmap, title, filepath, vmin, vmax):
    plt.figure(figsize=(10, 8))
    sns.heatmap(data.set_index(data.columns[0]), cmap=cmap, vmin=vmin, vmax=vmax)
    plt.title(title)
    plt.xlabel('Period')
    plt.savefig(filepath, format='tif', dpi=600)
    plt.close()  


draw_and_save_heatmap(data1, cmap, '1541000', "C:/Users/Administrator/Desktop/Figures/4.results/1541000.tif", global_min, global_max)
