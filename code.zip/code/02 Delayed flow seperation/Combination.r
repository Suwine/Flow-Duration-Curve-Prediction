#Merge the outputs from 'Batch processing of DFI.R' and 'MAM_MQ.R' into one table.
copy_dfi_to_result <- function(result_path, dfi_dir_path, save_path){

  data <- read.csv(result_path) 
   for (i in 1:90) {
    Ni <- paste0("N", i)
    data[[Ni]] <- c(0)
  }
  cnt <- 0
  for (csv_name in data[, 1]) {
     dfi_path <- file.path(dfi_dir_path, paste0("dfi_baseflow_", csv_name))
    dfi_data <- read.csv(dfi_path)
      cnt <- cnt + 1
    

    for (i in 1:90) {
      Ni <- paste0("N", i)

      data[[Ni]][cnt] <- dfi_data[[Ni]][1]
    }
  }

  write.csv(data, file = save_path, row.names = F)
}
copy_dfi_to_result("C:\\Users\\Administrator\\Desktop\\MAM_MQ\\result\\result.csv",
                   "C:\\Users\\Administrator\\Desktop\\dfi", 
                   "C:\\Users\\Administrator\\Desktop\\dfi_result\\dfi_result.csv")