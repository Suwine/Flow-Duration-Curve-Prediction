#Calculate the DFI values for 90 time blocks.
dfi <- function(input_directory, output_directory) {
  current_path <- normalizePath(dirname(rstudioapi::getActiveDocumentContext()$path))

  input_path <- file.path(current_path, input_directory)
  output_path <- file.path(current_path, output_directory)

  csv_files <- list.files(path = input_path, pattern = "\\.csv$", 
                          full.names = TRUE)

  for (csv_file in csv_files) {
  data <- read.csv(csv_file)
    

    n_sum <- colSums(data[, 3:92])
    n_i <- n_sum / sum(data$Q)
    

    output <- data.frame(t(n_i))
    colnames(output) <- paste0("N", 1:90)

    output_file <- file.path(output_path, 
                             paste0("dfi_", basename(csv_file)))

    write.csv(output, file = output_file, row.names = FALSE)
  }
}
dfi("baseflow", "dfi")