%Run the K-means algorithm with the number of clusters determined by 'sensitivity_analysis.m'.
for i=1:10
    TOL = 0.0004;
    ITER = 5000;
    kappa = 4;
    X = data;
    tic;
    [C, I, iter] = myKmeans(X, kappa, ITER, TOL);
    toc
    disp(['k-means instance took ' int2str(iter) ' iterations to complete']);
end

  