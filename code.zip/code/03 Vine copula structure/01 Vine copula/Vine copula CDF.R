%Based on the selected optimal Vine copula structure, calculate the joint CDF for four delayed flows.
library(readxl)
library(VineCopula)
library(openxlsx)

copula_data <- read_excel("123,124.xlsx")
u1 <- copula_data$CDF_Values_1
u2 <- copula_data$CDF_Values_2


cop <- BiCop(family=5, par=-0.15)  #Frank

cdf_values <- BiCopCDF(u1, u2, cop)


cdf_data <- data.frame(CDF_Value= cdf_values)

write.xlsx(cdf_data, file = "CDF.xlsx")