# Calculate the maximum and average flow values.
if (!require("tidyverse")) {
  install.packages("tidyverse")
}
library(tidyverse)
options(encoding = "UTF-8")

min_by_year_csv <- function {

  data <- read.csv(文件路径, fileEncoding = "UTF-8")
  
  min_by_year <- aggregate(Q ~ substr(DATE, 7, 8), data = data, min)

  mean_value <- mean(data$Q, na.rm = TRUE) # na.rm
  output_file_path <- file.path(, paste0("", basename()))
  min_by_year$average <- mean_value
  write.csv(min_by_year, output_file_path, row.names = FALSE)

  return(output_file_path)
}

min_by_year_csv_all <- function {
  csv_files <- list.files(, pattern = "\\.csv$", full.names = TRUE)
  
  output_files <- lapply(csv_files, function(file_path) {
    min_by_year_csv(file_path, )
  })
  

  return(output_files)
}

mean_by_file_csv <- function() {
  csv_files <- list.files(, pattern = "\\.csv$", full.names = TRUE)

  mean_values <- lapply(csv_files, function(file_path) {
    data <- read.csv(file_path, fileEncoding = "UTF-8", stringsAsFactors = FALSE)
    mean_value <- mean(data[, 2])
    return(list(file_name = basename(file_path), 
                "MAM" = mean_value,
                "MQ" = data[2, 3], 
                "MAM/MQ" = mean_value / data[2, 3]))
    
  })
  
  write.csv(do.call(rbind, mean_values), , row.names = FALSE, fileEncoding = "UTF-8")
  

  return()
}

script_path <- dirname(rstudioapi::getSourceEditorContext()$path)

input_path <- file.path(script_path, "continuous")
output_path <- file.path(script_path, "MAM_MQ")
save_file_path <- file.path(output_path, "result", "result.csv")

min_by_year_csv_all(input_path, output_path)
mean_by_file_csv(output_path, save_file_path)