%Transfer model parameters from the hydrologically most similar basins to ungauged basins.
load('basin_data.mat'); 
corrMatrix = corr(data{:, 1:end-5}, data{:, end-4:end});
significantDescriptors = max(abs(corrMatrix), [], 2) > 0.5; 
selectedData = data(:, significantDescriptors);
selectedData.avgFeature = mean([selectedData.feature1, selectedData.feature2], 2);
selectedData(:, {'feature1', 'feature2'}) = [];
Y = selectedData{:, end-4}; 
X = selectedData{:, 1:end-5};
numTrees = 100; 
rfModel = TreeBagger(numTrees, X, Y, 'Method', 'regression', 'OOBPrediction', 'On');
load('ungauged_basin_data.mat'); 
ungaugedData.avgFeature = mean([ungaugedData.feature1, ungaugedData.feature2], 2);
ungaugedData(:, {'feature1', 'feature2'}) = [];
ungaugedX = ungaugedData(:, 1:end-1);
predictedParams = predict(rfModel, ungaugedX);
disp(predictedParams);
