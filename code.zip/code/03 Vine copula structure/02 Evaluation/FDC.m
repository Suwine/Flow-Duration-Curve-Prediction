%Plot the FDC curve based on the CDF data obtained from the 01 Vine copula section
flow0 =Q_FDC_Cali.hanjiang.obs;
flow = Q_FDC_Cali.hanjiang.sim;
cdf_values = Q_FDC_Cali.hanjiang.CDFplus;
cdf_values1=Q_FDC_Cali.hanjiang.CDF;

exceedence_probability1 = 1 - cdf_values1;
exceedence_probability = 1 - cdf_values;
sorted_data2 = sort(flow,'descend');
exceedence_probability2 = (1:length(sorted_data2)) / length(sorted_data2;
plot(exceedence_probability2, sorted_data2,  'Color', [157/255, 57/255, 75/255], 'LineWidth',3);
hold on 
[sorted_exceedence_probability, sort_index] = sort(exceedence_probability);
sorted_flow = sort(flow,'descend');
[sorted_exceedence_probability1, sort_index1] = sort(exceedence_probability1);
sorted_data1 = sort(flow0,'descend');
exceedence1 = (1:length(sorted_data1)) / length(sorted_data1); 
plot(sorted_exceedence_probability, sorted_flow, 'Color', [233/255, 178/255, 101/255], 'LineWidth', 3);
hold on; 
plot(sorted_exceedence_probability1, sorted_flow,'Color',  [67/255, 202/255, 215/255], 'LineWidth',3);
hold on; 
plot(exceedence1, sorted_data1, 'Color',  [21/255, 112/255, 166/255], 'LineWidth',3);
title('Comparison of Flow Duration Curves');
xlabel('Exceedence Probability ');
ylabel('Flow');
set(gca, 'YScale', 'log');
grid off;