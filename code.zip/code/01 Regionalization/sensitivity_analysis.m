%To determine the optimal number of clusters for the K-means algorithm.

function sensitivity_analysis(data, max_clusters)
    evaluation_results = zeros(max_clusters, 2);
    silhouette_avg = zeros(max_clusters, 1);

    for k = 1:max_clusters
        [idx, C] = kmeans(data, k);
        evaluation_results(k, 1) = evaluate_clusters_correlation(data, idx, C);
        if k > 1 
            silhouette_values = silhouette(data, idx);
            silhouette_avg(k) = mean(silhouette_values);
        end
    end

    evaluation_results(:, 2) = silhouette_avg;

    figure;
    subplot(1,2,1); 
    barh(evaluation_results(:,1), 'FaceColor', [0 0.4470 0.7410]);
    title('Correlation Distance by Number of Clusters');
    xlabel('Correlation Distance');
    set(gca, 'YTick', 1:max_clusters, 'YTickLabel', arrayfun(@num2str, 1:max_clusters, 'UniformOutput', false));
    xlim([min(evaluation_results(:,1))*0.9, max(evaluation_results(:,1))*1.1]); 
    subplot(1,2,2);
    barh(evaluation_results(:,2), 'FaceColor', [0.8500 0.3250 0.0980]);
    title('Silhouette Coefficient by Number of Clusters');
    xlabel('Silhouette Coefficient');
    set(gca, 'YTick', 1:max_clusters, 'YTickLabel', arrayfun(@num2str, 1:max_clusters, 'UniformOutput', false));
    xlim([min(evaluation_results(:,2))*0.9, max(evaluation_results(:,2))*1.1]); 

    drawnow;
end

function correlation_distance = evaluate_clusters_correlation(data, clusters, centroids)
    total_correlation_distance = 0;
    for i = 1:size(data, 1)
        cluster_idx = clusters(i);
        centroid = centroids(cluster_idx, :);
        correlation_distance = 1 - corr(data(i, :)', centroid');
        total_correlation_distance = total_correlation_distance + correlation_distance;
    end
    correlation_distance = total_correlation_distance / size(data, 1);
end


