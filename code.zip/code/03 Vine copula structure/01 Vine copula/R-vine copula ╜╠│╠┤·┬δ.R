rm(list = ls())
library(readxl)
library(tseries)
library(FinTS)

data = read_xlsx("N05582000.xlsx") 
data_series = ts(data[,2:5])

#ret_series = log(data_series/lag(data_series,1L))
#ret_series

m1 = as.ts(data_series[,1])
m2 = as.ts(data_series[,2])
m3 = as.ts(data_series[,3])
m4 = as.ts(data_series[,4]) 



adf.test(m1)
adf.test(m2)
adf.test(m3)
adf.test(m4)



jarque.bera.test(m1)
jarque.bera.test(m2)
jarque.bera.test(m3)
jarque.bera.test(m4)


Box.test (m1, lag = 20, type = "Ljung")
Box.test (m2, lag = 20, type = "Ljung")
Box.test (m3, lag = 20, type = "Ljung")
Box.test (m4, lag = 20, type = "Ljung")


library(FinTS)
ArchTest (m1, lags=20, demean = FALSE) 
ArchTest (m2, lags=20, demean = FALSE) 
ArchTest (m3, lags=20, demean = FALSE) 
ArchTest (m4, lags=20, demean = FALSE) 



cor(data_series)


library(pastecs)
stat.desc(data_series,norm = TRUE)


m1_acf = acf(m1,plot = T)
am1_pacf = pacf(m1,plot = T)
m2_acf = acf(m2,plot = T)
m2_pacf = pacf(m2,plot = T)
m3_acf = acf(m3,plot = T)
m3_pacf = pacf(m3,plot = T)
m4_acf = acf(m4,plot = T)
m4_pacf = pacf(m4,plot = T)



library(zoo)
library(forecast)
auto.arima(m1) #arima(1,0,0)
auto.arima(m2) #arima(1,0,0)
auto.arima(m3) #arima(0,0,1)
auto.arima(m4) #arima(2,0,2)





library(rugarch)
spec_m1 <- ugarchspec(variance.model = list(model = "sGARCH", 
                                            garchOrder = c(1, 1), 
                                            submodel = NULL, 
                                            external.regressors = NULL, 
                                            variance.targeting = FALSE), 
                      
                      mean.model     = list(armaOrder = c(1, 0), 
                                            external.regressors = NULL), 
                      distribution.model="sstd", 
                      start.pars = list(), 
                      fixed.pars = list())
garch_m1 <- ugarchfit(spec = spec_m1, data = m1, solver.control = list(trace=0))

spec_m2 <- ugarchspec(variance.model = list(model = "sGARCH", 
                                            garchOrder = c(1, 1), 
                                            submodel = NULL, 
                                            external.regressors = NULL, 
                                            variance.targeting = FALSE), 
                      
                      mean.model     = list(armaOrder = c(1, 0), 
                                            external.regressors = NULL), 
                      distribution.model="sstd", 
                      start.pars = list(), 
                      fixed.pars = list())
garch_m2 <- ugarchfit(spec = spec_m2, data = m2, solver.control = list(trace=0))

spec_m3 <- ugarchspec(variance.model = list(model = "sGARCH", 
                                            garchOrder = c(1, 1), 
                                            submodel = NULL, 
                                            external.regressors = NULL, 
                                            variance.targeting = FALSE), 
                      
                      mean.model     = list(armaOrder = c(0, 1), 
                                            external.regressors = NULL), 
                      distribution.model="sstd", 
                      start.pars = list(), 
                      fixed.pars = list())
garch_m3 <- ugarchfit(spec = spec_m3, data = m3, solver.control = list(trace=0))

spec_m4 <- ugarchspec(variance.model = list(model = "sGARCH", 
                                            garchOrder = c(1, 1), 
                                            submodel = NULL, 
                                            external.regressors = NULL, 
                                            variance.targeting = FALSE), 
                      
                      mean.model     = list(armaOrder = c(2, 2), 
                                            external.regressors = NULL), 
                      distribution.model="sstd", 
                      start.pars = list(), 
                      fixed.pars = list())
garch_m4 <- ugarchfit(spec = spec_m4, data = m4, solver.control = list(trace=0))


sigma_matrix = matrix(data = c(garch_m1@fit$sigma,garch_m2@fit$sigma,garch_m3@fit$sigma,
                               garch_m4@fit$sigma),
                      nrow = length(garch_m1@fit$sigma),ncol = 4,byrow=FALSE)
residual_matrix = matrix(data = c(garch_m1@fit$residuals,garch_m2@fit$residuals,garch_m3@fit$residuals,
                                  garch_m4@fit$residuals),
                         nrow = length(garch_m1@fit$residuals),ncol = 4,byrow=FALSE)


std_sigma_matrix = matrix(nrow = 4376,ncol = 4)
copuladata = matrix(nrow = 4376,ncol = 4)
for (i in c(1:4)) {
  std_sigma_matrix[,i] = residual_matrix[,i]/sigma_matrix[,i]
  f = ecdf(as.numeric(std_sigma_matrix[,i]))
  copuladata[,i] = f(std_sigma_matrix[,i])
}


library(VineCopula)
library(copula)
library(CDVine)

Rst = RVineStructureSelect(copuladata,family = c(1:6),progress = TRUE,se = TRUE,method = 'itau',rotations = TRUE)
summary(Rst)
RVineTreePlot(Rst)
contour(Rst)
Rst$pair.AIC
Rst$pair.logLik
Rst$par
Rst$se
Rst$tau


